angular.module('app.controllers', [])
  
.controller('caesarCypherDefaultPageCtrl', function($scope) {

})
   
.controller('railFenceDefaultPageCtrl', function($scope) {

})
   
.controller('routeTranspositionDefaultPageCtrl', function($scope) {

})
      
.controller('caesarCypherDefinitionCtrl', function($scope) {

})
   
.controller('railFenceDefinitionCtrl', function($scope) {

})
   
.controller('routeTranspositionDefinitionCtrl', function($scope) {

})
   
.controller('caesarCypherExampleCtrl', function($scope) {

})
   
.controller('caesarCypherExampleEncryptedCtrl', function($scope) {

})
   
.controller('caesarCypherExampleDecryptedCtrl', function($scope) {

})
   
.controller('caesarCypherPracticeCtrl', function($scope) {

})
   
.controller('caesarPractice1Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question5ACtrl', function($scope) {

})
   
.controller('congratulationsPracticeCaesar1Ctrl', function($scope) {

})
   
.controller('congratulationsPracticeCaesar2Ctrl', function($scope) {

})
   
.controller('congratulationsPracticeCaesar3Ctrl', function($scope) {

})
   
.controller('congratulationsPracticeCaesar4Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question5ACtrl', function($scope) {

})
   
.controller('caesarCypherQuizCtrl', function($scope) {

})
   
.controller('caesarQuiz1Question1Ctrl', function($scope) {

})
 