angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController.caesarCypherDefaultPage', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherDefaultPage.html',
        controller: 'caesarCypherDefaultPageCtrl'
      }
    }
  })

  .state('tabsController.railFenceDefaultPage', {
    url: '/page3',
    views: {
      'tab2': {
        templateUrl: 'templates/railFenceDefaultPage.html',
        controller: 'railFenceDefaultPageCtrl'
      }
    }
  })

  .state('tabsController.routeTranspositionDefaultPage', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/routeTranspositionDefaultPage.html',
        controller: 'routeTranspositionDefaultPageCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.caesarCypherDefinition', {
    url: '/page5',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherDefinition.html',
        controller: 'caesarCypherDefinitionCtrl'
      }
    }
  })

  .state('tabsController.railFenceDefinition', {
    url: '/page6',
    views: {
      'tab2': {
        templateUrl: 'templates/railFenceDefinition.html',
        controller: 'railFenceDefinitionCtrl'
      }
    }
  })

  .state('tabsController.routeTranspositionDefinition', {
    url: '/page7',
    views: {
      'tab3': {
        templateUrl: 'templates/routeTranspositionDefinition.html',
        controller: 'routeTranspositionDefinitionCtrl'
      }
    }
  })

  .state('tabsController.caesarCypherExample', {
    url: '/page8',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherExample.html',
        controller: 'caesarCypherExampleCtrl'
      }
    }
  })

  .state('tabsController.caesarCypherExampleEncrypted', {
    url: '/page9',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherExampleEncrypted.html',
        controller: 'caesarCypherExampleEncryptedCtrl'
      }
    }
  })

  .state('tabsController.caesarCypherExampleDecrypted', {
    url: '/page10',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherExampleDecrypted.html',
        controller: 'caesarCypherExampleDecryptedCtrl'
      }
    }
  })

  .state('tabsController.caesarCypherPractice', {
    url: '/page11',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarCypherPractice.html',
        controller: 'caesarCypherPracticeCtrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question1', {
    url: '/page12',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question1.html',
        controller: 'caesarPractice1Question1Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question1A', {
    url: '/page43',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question1A.html',
        controller: 'caesarPractice1Question1ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question2', {
    url: '/page14',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question2.html',
        controller: 'caesarPractice1Question2Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question2A', {
    url: '/page44',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question2A.html',
        controller: 'caesarPractice1Question2ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question3', {
    url: '/page15',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question3.html',
        controller: 'caesarPractice1Question3Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question3A', {
    url: '/page45',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question3A.html',
        controller: 'caesarPractice1Question3ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question4', {
    url: '/page16',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question4.html',
        controller: 'caesarPractice1Question4Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question4A', {
    url: '/page46',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question4A.html',
        controller: 'caesarPractice1Question4ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question5', {
    url: '/page17',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question5.html',
        controller: 'caesarPractice1Question5Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice1Question5A', {
    url: '/page47',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice1Question5A.html',
        controller: 'caesarPractice1Question5ACtrl'
      }
    }
  })

  .state('tabsController.congratulationsPracticeCaesar1', {
    url: '/page13',
    views: {
      'tab1': {
        templateUrl: 'templates/congratulationsPracticeCaesar1.html',
        controller: 'congratulationsPracticeCaesar1Ctrl'
      }
    }
  })

  .state('congratulationsPracticeCaesar2', {
    url: '/page24',
    templateUrl: 'templates/congratulationsPracticeCaesar2.html',
    controller: 'congratulationsPracticeCaesar2Ctrl'
  })

  .state('congratulationsPracticeCaesar3', {
    url: '/page31',
    templateUrl: 'templates/congratulationsPracticeCaesar3.html',
    controller: 'congratulationsPracticeCaesar3Ctrl'
  })

  .state('congratulationsPracticeCaesar4', {
    url: '/page36',
    templateUrl: 'templates/congratulationsPracticeCaesar4.html',
    controller: 'congratulationsPracticeCaesar4Ctrl'
  })

  .state('tabsController.caesarPractice2Question1', {
    url: '/page18',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question1.html',
        controller: 'caesarPractice2Question1Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question1A', {
    url: '/page48',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question1A.html',
        controller: 'caesarPractice2Question1ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question2', {
    url: '/page20',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question2.html',
        controller: 'caesarPractice2Question2Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question2A', {
    url: '/page49',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question2A.html',
        controller: 'caesarPractice2Question2ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question3', {
    url: '/page21',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question3.html',
        controller: 'caesarPractice2Question3Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question3A', {
    url: '/page50',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question3A.html',
        controller: 'caesarPractice2Question3ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question4', {
    url: '/page22',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question4.html',
        controller: 'caesarPractice2Question4Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question4A', {
    url: '/page51',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question4A.html',
        controller: 'caesarPractice2Question4ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question5', {
    url: '/page23',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question5.html',
        controller: 'caesarPractice2Question5Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice2Question5A', {
    url: '/page52',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice2Question5A.html',
        controller: 'caesarPractice2Question5ACtrl'
      }
    }
  })

  .state('caesarPractice3Question1', {
    url: '/page25',
    templateUrl: 'templates/caesarPractice3Question1.html',
    controller: 'caesarPractice3Question1Ctrl'
  })

  .state('caesarPractice3Question1A', {
    url: '/page53',
    templateUrl: 'templates/caesarPractice3Question1A.html',
    controller: 'caesarPractice3Question1ACtrl'
  })

  .state('caesarPractice3Question2', {
    url: '/page26',
    templateUrl: 'templates/caesarPractice3Question2.html',
    controller: 'caesarPractice3Question2Ctrl'
  })

  .state('caesarPractice3Question2A', {
    url: '/page54',
    templateUrl: 'templates/caesarPractice3Question2A.html',
    controller: 'caesarPractice3Question2ACtrl'
  })

  .state('caesarPractice3Question3', {
    url: '/page27',
    templateUrl: 'templates/caesarPractice3Question3.html',
    controller: 'caesarPractice3Question3Ctrl'
  })

  .state('caesarPractice3Question3A', {
    url: '/page55',
    templateUrl: 'templates/caesarPractice3Question3A.html',
    controller: 'caesarPractice3Question3ACtrl'
  })

  .state('caesarPractice3Question4', {
    url: '/page28',
    templateUrl: 'templates/caesarPractice3Question4.html',
    controller: 'caesarPractice3Question4Ctrl'
  })

  .state('caesarPractice3Question4A', {
    url: '/page56',
    templateUrl: 'templates/caesarPractice3Question4A.html',
    controller: 'caesarPractice3Question4ACtrl'
  })

  .state('caesarPractice3Question5', {
    url: '/page29',
    templateUrl: 'templates/caesarPractice3Question5.html',
    controller: 'caesarPractice3Question5Ctrl'
  })

  .state('caesarPractice3Question5A', {
    url: '/page57',
    templateUrl: 'templates/caesarPractice3Question5A.html',
    controller: 'caesarPractice3Question5ACtrl'
  })

  .state('tabsController.caesarPractice4Question1', {
    url: '/page30',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question1.html',
        controller: 'caesarPractice4Question1Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question1A', {
    url: '/page58',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question1A.html',
        controller: 'caesarPractice4Question1ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question2', {
    url: '/page32',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question2.html',
        controller: 'caesarPractice4Question2Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question2A', {
    url: '/page59',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question2A.html',
        controller: 'caesarPractice4Question2ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question3', {
    url: '/page33',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question3.html',
        controller: 'caesarPractice4Question3Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question3A', {
    url: '/page60',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question3A.html',
        controller: 'caesarPractice4Question3ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question4', {
    url: '/page34',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question4.html',
        controller: 'caesarPractice4Question4Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question4A', {
    url: '/page61',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question4A.html',
        controller: 'caesarPractice4Question4ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question5', {
    url: '/page35',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question5.html',
        controller: 'caesarPractice4Question5Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice4Question5A', {
    url: '/page62',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice4Question5A.html',
        controller: 'caesarPractice4Question5ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question1', {
    url: '/page38',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question1.html',
        controller: 'caesarPractice5Question1Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question1A', {
    url: '/page63',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question1A.html',
        controller: 'caesarPractice5Question1ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question2', {
    url: '/page39',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question2.html',
        controller: 'caesarPractice5Question2Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question2A', {
    url: '/page64',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question2A.html',
        controller: 'caesarPractice5Question2ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question3', {
    url: '/page40',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question3.html',
        controller: 'caesarPractice5Question3Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question3A', {
    url: '/page65',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question3A.html',
        controller: 'caesarPractice5Question3ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question4', {
    url: '/page41',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question4.html',
        controller: 'caesarPractice5Question4Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question4A', {
    url: '/page66',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question4A.html',
        controller: 'caesarPractice5Question4ACtrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question5', {
    url: '/page42',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question5.html',
        controller: 'caesarPractice5Question5Ctrl'
      }
    }
  })

  .state('tabsController.caesarPractice5Question5A', {
    url: '/page67',
    views: {
      'tab1': {
        templateUrl: 'templates/caesarPractice5Question5A.html',
        controller: 'caesarPractice5Question5ACtrl'
      }
    }
  })

  .state('caesarCypherQuiz', {
    url: '/page19',
    templateUrl: 'templates/caesarCypherQuiz.html',
    controller: 'caesarCypherQuizCtrl'
  })

  .state('caesarQuiz1Question1', {
    url: '/page37',
    templateUrl: 'templates/caesarQuiz1Question1.html',
    controller: 'caesarQuiz1Question1Ctrl'
  })

$urlRouterProvider.otherwise('/page1/page2')

  

});