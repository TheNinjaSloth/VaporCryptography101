angular.module('app.controllers', [])
  
.controller('railFenceDefaultPageCtrl', function($scope) {

})
   
.controller('routeTranspositionDefaultPageCtrl', function($scope) {

})
      
.controller('caesarCypherDefinitionCtrl', function($scope) {

})
   
.controller('railFenceDefinitionCtrl', function($scope) {

})
   
.controller('routeTranspositionDefinitionCtrl', function($scope) {

})
   
.controller('caesarCypherExampleCtrl', function($scope) {

})
   
.controller('caesarCypherExampleEncryptedCtrl', function($scope) {

})
   
.controller('caesarCypherExampleDecryptedCtrl', function($scope) {

})
   
.controller('caesarCypherPracticeCtrl', function($scope) {

})
   
.controller('caesarPractice1Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice1Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice1Question5ACtrl', function($scope) {

})
   
.controller('congratulationsCtrl', function($scope) {

})
   
.controller('caesarPractice2Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice2Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice2Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice3Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice3Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice4Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice4Question5ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question1Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question1ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question2Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question2ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question3Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question3ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question4Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question4ACtrl', function($scope) {

})
   
.controller('caesarPractice5Question5Ctrl', function($scope) {

})
   
.controller('caesarPractice5Question5ACtrl', function($scope) {

})
   
.controller('caesarCypherQuizCtrl', function($scope) {

})
   
.controller('caesarQuiz1Question1Ctrl', function($scope) {

})
   
.controller('caesarQuiz1Question2Ctrl', function($scope) {

})
   
.controller('caesarQuiz1Question3Ctrl', function($scope) {

})
   
.controller('caesarQuiz1Question4Ctrl', function($scope) {

})
   
.controller('caesarQuiz1Question5Ctrl', function($scope) {

})
   
.controller('quiz1CompletedCtrl', function($scope) {

})
   
.controller('caesarQuiz2Question1Ctrl', function($scope) {

})
   
.controller('caesarQuiz2Question2Ctrl', function($scope) {

})
   
.controller('caesarQuiz2Question3Ctrl', function($scope) {

})
   
.controller('caesarQuiz2Question4Ctrl', function($scope) {

})
   
.controller('caesarQuiz2Question5Ctrl', function($scope) {

})
   
.controller('quiz2CompletedCtrl', function($scope) {

})
   
.controller('railfenceExampleCtrl', function($scope) {

})
   
.controller('railfenceExampleEncryptedCtrl', function($scope) {

})
   
.controller('railfenceExampleDecryptedCtrl', function($scope) {

})
   
.controller('railFencePracticeCtrl', function($scope) {

})
   
.controller('railfencePractice1Question1Ctrl', function($scope) {

})
   
.controller('railfencePractice1Question1ACtrl', function($scope) {

})
   
.controller('railfencePractice1Question2Ctrl', function($scope) {

})
   
.controller('railfencePractice1Question2ACtrl', function($scope) {

})
   
.controller('railfencePractice1Question3Ctrl', function($scope) {

})
   
.controller('railfencePractice1Question3ACtrl', function($scope) {

})
   
.controller('railfencePractice1Question4Ctrl', function($scope) {

})
   
.controller('railfencePractice1Question4ACtrl', function($scope) {

})
   
.controller('railfencePractice1Question5Ctrl', function($scope) {

})
   
.controller('railfencePractice1Question5ACtrl', function($scope) {

})
   
.controller('railfencePractice2Question1Ctrl', function($scope) {

})
   
.controller('railfencePractice2Question1ACtrl', function($scope) {

})
   
.controller('railfencePractice2Question2Ctrl', function($scope) {

})
   
.controller('railfencePractice2Question2ACtrl', function($scope) {

})
   
.controller('railfencePractice2Question3Ctrl', function($scope) {

})
   
.controller('railfencePractice2Question3ACtrl', function($scope) {

})
   
.controller('railfencePractice2Question4Ctrl', function($scope) {

})
   
.controller('railfencePractice2Question4ACtrl', function($scope) {

})
   
.controller('railfencePractice2Question5Ctrl', function($scope) {

})
   
.controller('railfencePractice2Question5ACtrl', function($scope) {

})
   
.controller('railfencePractice3Question1Ctrl', function($scope) {

})
   
.controller('railfencePractice3Question1ACtrl', function($scope) {

})
   
.controller('railfencePractice3Question2Ctrl', function($scope) {

})
   
.controller('railfencePractice3Question2ACtrl', function($scope) {

})
   
.controller('railfencePractice3Question3Ctrl', function($scope) {

})
   
.controller('railfencePractice3Question3ACtrl', function($scope) {

})
   
.controller('railfencePractice3Question4Ctrl', function($scope) {

})
   
.controller('railfencePractice3Question4ACtrl', function($scope) {

})
   
.controller('railfencePractice3Question5Ctrl', function($scope) {

})
   
.controller('railfencePractice3Question5ACtrl', function($scope) {

})
   
.controller('railfencePractice4Question1Ctrl', function($scope) {

})
   
.controller('railfencePractice4Question1ACtrl', function($scope) {

})
   
.controller('railfencePractice4Question2Ctrl', function($scope) {

})
   
.controller('railfencePractice4Question2ACtrl', function($scope) {

})
   
.controller('railfencePractice4Question3Ctrl', function($scope) {

})
   
.controller('railfencePractice4Question3ACtrl', function($scope) {

})
   
.controller('railfencePractice4Question4Ctrl', function($scope) {

})
   
.controller('railfencePractice4Question4ACtrl', function($scope) {

})
   
.controller('railfencePractice4Question5Ctrl', function($scope) {

})
   
.controller('railfencePractice4Question5ACtrl', function($scope) {

})
   
.controller('railfencePractice5Question1Ctrl', function($scope) {

})
   
.controller('railfencePractice5Question1ACtrl', function($scope) {

})
   
.controller('railfencePractice5Question2Ctrl', function($scope) {

})
   
.controller('railfencePractice5Question2ACtrl', function($scope) {

})
   
.controller('railfencePractice5Question3Ctrl', function($scope) {

})
   
.controller('railfencePractice5Question3ACtrl', function($scope) {

})
   
.controller('railfencePractice5Question4Ctrl', function($scope) {

})
   
.controller('railfencePractice5Question4ACtrl', function($scope) {

})
   
.controller('railfencePractice5Question5Ctrl', function($scope) {

})
   
.controller('railfencePractice5Question5ACtrl', function($scope) {

})
   
.controller('railfenceQuizCtrl', function($scope) {

})
   
.controller('railfenceQuiz1Question1Ctrl', function($scope) {

})
   
.controller('railfenceQuiz1Question2Ctrl', function($scope) {

})
   
.controller('railfenceQuiz1Question3Ctrl', function($scope) {

})
   
.controller('railfenceQuiz1Question4Ctrl', function($scope) {

})
   
.controller('railfenceQuiz1Question5Ctrl', function($scope) {

})
   
.controller('railfenceQuiz1CongratsCtrl', function($scope) {

})
   
.controller('railfenceQuiz2Question1Ctrl', function($scope) {

})
   
.controller('railfenceQuiz2Question2Ctrl', function($scope) {

})
   
.controller('railfenceQuiz2Question3Ctrl', function($scope) {

})
   
.controller('railfenceQuiz2Question4Ctrl', function($scope) {

})
   
.controller('railfenceQuiz2Question5Ctrl', function($scope) {

})
   
.controller('railfenceQuiz2CongratsCtrl', function($scope) {

})
   
.controller('caesarCipherDefaultPageCtrl', function($scope) {

})
 